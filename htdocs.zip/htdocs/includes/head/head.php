<body>
    <header class="header--full">
        <!-- header top -->
        <header class="header__about--top">
            <div class="container">
                <div style="font-weight: bold;" class="header__about">
                    
                <!-- header top icon on mobile -->
                    <div class="header__about--top-mobile col-md-0 col-l-0">
                        
                        <div id="header__about--icon-mobile" class="header__about--connect-mobile"></div>
                        <i class="header__about--icon-mobile fa-solid fa-play"></i>
                        
                        <!-- header about list on mobile -->
                        
                        <ul id="header__bars--list-mobile" class="header__navbar--list header__about--list col-l-0 col-md-0">
                            <div class="header__bars--connect-mobile"></div>
                            
                            <!-- news -->
                            <li class="header__navbar--items">
                                <a href="/" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">TRANG CHỦ</p> 
                                </a>
                            </li>
                            <!-- film -->
                            <li class="header__navbar--items">
                                <a href="/movie" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">PHIM</p> 
                                </a>
                            </li>
                            <!-- clusters -->
                            <li class="header__navbar--items">
                                <a href="/clusters" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">DANH MỤC</p> 
                                </a>
                            </li>

                        </ul>
                    </div>
                
                <!-- PC, Tablet -->

                    <div class="header__about--logo col-sm-0">
                        <a class="header__about--link" href="/">
                            <!-- <p class="header__about--para">NEWS</p> -->
                            <img class="header__navbar--img" src="../assets/img/webicon.jpg" alt="cinema-logo" srcset="">
                        </a>    
                    </div>

                    <div class="header__about--films col-sm-0">
                        <a class="header__about--link" href="/movie">
                            <p class="header__about--para">PHIM</p> 
                        </a> 
                    </div>

                    <div class="header__about--ticket-clusters col-sm-0">
                        <a class="header__about--link" href="/clusters">
                            <p class="header__about--para">DANH MỤC</p> 
                        </a>    
                    </div>

                    <div class="header__about--login_signup">
                        <i style="cursor: default;" class="fa-solid fa-user header__about--icon"></i>

                        <div style="margin-right: 3px;" class="header__about--login" id="header__about--user-account">
                            <a href="/user_account?user=account" class="login-link header__about--link">
                                <p class='header__about--para'><?php
                                    $username = $_SESSION['login_phone'];
                                    echo getName($username);
                                ?>
                                
                                </p>
                            </a>
                        </div>

                        <p style="cursor: default;" class="header__about--para">/</p>

                        <div style="margin-right: 3px;" class="header__about--login d-none" id="header__about--login">
                            <a href="../main/login_signup.php" class="login-link header__about--link">
                                <p class="header__about--para">Đăng nhập</p> 
                            </a>
                        </div>
                        
                        <form style="display: flex;" action="" method="post">
                            <div style="margin-top: 1px;" class="header__about--signup" id="header__about--signup">
                                <a href="" class="signup-link header__about--link">
                                    
                                    <button name="log-out__btn" class="header__about--log-out header__about--para">
                                       Đăng xuất
                                    </button> 
                                </a>
                            </div>
                            <?php
                                if(isset($_POST['log-out__btn'])){
                                    unset($_SESSION['login_phone']);
                                    unset($_SESSION['login_pass']);
                                    unset($_SESSION['voucher_id']);
                                    unset($_SESSION['pakage_id']);
                                    unset($_SESSION['filmID']);
                                    unset($_SESSION['area_ID']);
                                    unset($_SESSION['sht_ID']);
                                    unset($_SESSION['cluster_ID']);
                                    header('location: login_signup.php?page=login_signup');
                                }
                            ?>
                        </form>
                    </div>


                </div>
            </div>
        </header>

    </header>    
    
</body>
</html>