<body>
    <header class="header--full">
        <!-- header top -->
        <header class="header__about--top">
            <div class="container">
                <div style="font-weight: bold;" class="header__about">
                    
                <!-- header top icon on mobile -->
                    <div class="header__about--top-mobile col-md-0 col-l-0">
                        
                        <div id="header__about--icon-mobile" class="header__about--connect-mobile"></div>
                        <i class="header__about--icon-mobile fa-solid fa-play"></i>
                        
                        <ul id="header__bars--list-mobile" class="header__navbar--list header__about--list col-l-0 col-md-0">
                            <div class="header__bars--connect-mobile"></div>

                            <!-- packages -->
                            <li class="header__navbar--items">
                                <a href="/" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">TRANG CHỦ</p> 
                                </a>
                            </li>
                            
                            <!-- film -->
                            <li class="header__navbar--items">
                                <a href="?page=movie" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">PHIM</p> 
                                </a>
                            </li>
                            <!-- clusters -->
                            <li class="header__navbar--items">
                                <a href="?pageclusters" class="header__navbar--link">
                                    <p class="header__navbar--para-mobile header__navbar--para">DANH MỤC</p> 
                                </a>
                            </li>
                            
                        </ul>
                    </div>
                
                <!-- PC, Tablet -->

                    <div class="header__about--logo col-sm-0">
                        <a class="header__about--link" href="?page=main_page">
                            <!-- <p class="header__about--para">NEWS</p> -->
                            <img class="header__navbar--img" src="../assets/img/webicon.jpg" alt="cinema-logo" srcset="">
                        </a>    
                    </div>

                    <div class="header__about--films col-sm-0">
                        <a class="header__about--link" href="?page=movie">
                            <p class="header__about--para">PHIM</p> 
                        </a> 
                    </div>

                    <div class="header__about--ticket-clusters col-sm-0">
                        <a class="header__about--link" href="?page=clusters">
                            <p class="header__about--para">DANH MỤC</p> 
                        </a>    
                    </div>

                    <div class="header__about--login_signup">
                        <i style="cursor: default;" class="fa-solid fa-user header__about--icon"></i>

                        <div style="margin-right: 3px;" class="header__about--login d-none" id="header__about--user-account">
                            <a href="?page=user_account" class="login-link header__about--link">
                                <p class='header__about--para'>ĐẠT HỌC NGU</p>
                            </a>
                        </div>

                        <div style="margin-right: 3px;" class="header__about--login" id="header__about--login">
                            <a href="?page=login" class="login-link header__about--link">
                                <p class="header__about--para">Đăng nhập</p> 
                            </a>
                        </div>

                        <p style="cursor: default;" class="header__about--para">/</p>
                        
                        <div style="margin-left: 3px;" class="header__about--signup" id="header__about--signup">
                            <a href="?page=signup" class="signup-link header__about--link">
                                <p class="header__about--para">Đăng ký</p> 
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </header>

    </header>    
    
</body>
</html>