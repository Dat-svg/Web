- assets (css, js, img, video, font)
- includes (head, foot)
- Library (PHP Mailer Library)
- page (pages in php)
- vnpay_php (vnpay code)
- index.php, login_signup.php, manager_main.php, connect.php

Test VNPay card
Ngân hàng:	    NCB
Số thẻ:	        9704198526191432198
Tên chủ thẻ:	NGUYEN VAN A
Ngày phát hành:	07/15
Mật khẩu OTP:	123456

admin account: 
Phone number: admin
Password: 123456

customer account: 
Phone number: 0123456789
Password: 123456


