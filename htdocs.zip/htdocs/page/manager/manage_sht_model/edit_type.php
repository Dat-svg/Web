<?php
    require_once('../connectInMan.php');

    if(!empty($_POST['film_ID']) && !empty($_POST['shtID'])){
        $film_ID = $_POST['film_ID'];
        foreach(getFilmeTypeByFilmId($film_ID) as $row){
            $film_type = $row['type_Name'];
            
            ?>
                <option value="<?= $film_type ?>" class="manage-film__option--add-type"><?= $film_type ?></option>
                
            <?php

        }
    }
?>