<?php
// Tạo dữ liệu ngẫu nhiên cho biểu đồ cột
$labels = ["Label 1", "Label 2", "Label 3", "Label 4", "Label 5"];
$data = [rand(10, 100), rand(10, 100), rand(10, 100), rand(10, 100), rand(10, 100)];

// Trả về dữ liệu dưới dạng JSON
echo json_encode(['labels' => $labels, 'data' => $data]);
?>
