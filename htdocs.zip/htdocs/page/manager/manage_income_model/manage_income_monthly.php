<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Column Chart Demo</title>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<?php
    require_once('../connectInMan.php');
    if(!empty($_POST['month']) && !empty($_POST['choice']) && !empty($_POST['room'])){
        
        $month = $_POST['month'];
        $choice = $_POST['choice'];
        $room = $_POST['room'];

        $data = [];
        // monthly money
        if($choice == 'monthly_money'){
            $money = sumTicketPriceInMonth($month);
            $price = $money['sumTicket'];
            if($price != ""){
                // Thêm dữ liệu vào mảng
                $data[] = doubleval($price);
            }
            ?>
            <span class="manage-income__title">Tổng:</span>
            <span class="manage-income__title"><?php echo strval(number_format(doubleval($price))) ?></span>
            <span class="manage-income__title">$</span>
            <?php
        }
        // monthly ticket
        else if($choice == 'monthly_ticket'){
            if(!empty(countTicketInMonth($month))){
                $count = countTicketInMonth($month);
                $ticket_Count = $count['ticket_Count'];
                ?>
                <span class="manage-income__title">Tổng:</span>
                <span class="manage-income__title"><?php echo $ticket_Count ?></span>
                <span class="manage-income__title">vé trong <?= getMonth($month) ?></span>
                <?php
            }else{
                ?>
                <span style="color: red;" class="manage-income__title">Vui lòng chọn "tháng"!</span>
                <?php
            }
        }
        // hot film in month
        else if($choice == 'film_hot'){
            if($month == 'none'){
                ?>
                <span style="color: red;" class="manage-income__title">Vui lòng chọn "tháng"!</span>
                <?php
            } else if(!empty(hotFilmInMonth($month))){
                $dataFilmHot = hotFilmInMonth($month);
                $film = $dataFilmHot['film'];
                $count = $dataFilmHot['film_quan'];
                ?>
                <span class="manage-income__title"><?php echo ucfirst($film) ?></span>
                <span class="manage-income__title">với</span>
                <span class="manage-income__title"><?= $count ?></span>
                <span class="manage-income__title">vé trong tháng</span>
                <?php
            } else {
                ?>
                <span style="color: red;" class="manage-income__title">Không có dữ liệu!</span>
                <?php
            }
        }
        // booked seat in room in month
        else if($choice == "seat_book_in_month"){
            if($month == 'none'){
                ?>
                <span style="color: red;" class="manage-income__title">Vui lòng chọn "tháng"!</span>
                <?php
            } else if($room == 'none'){
                ?>
                <span style="color: red;" class="manage-income__title">Vui lòng chọn "phòng"!</span>
                <?php
            } else if(!empty(seatOfRoomBookedInMonth($room, $month))){
                $dataSeatOfRoom = seatOfRoomBookedInMonth($room, $month);
                $total_seat = $dataSeatOfRoom['total_seats'];
                ?>
                <span class="manage-income__title"><?php echo $total_seat ?></span>
                <span class="manage-income__title">seat(s) in <?= $room ?> is booked in <?= getMonth($month) ?></span>
                <?php
            } else {
                ?>
                <span style="color: red;" class="manage-income__title">Không có dữ liệu!</span>
                <?php
            }
        }
        // Button để hiển thị biểu đồ
        ?>
        <button id="showChartButton">Hiển thị biểu đồ</button>
        <div id="chartContainer">
            <!-- Nơi để vẽ biểu đồ -->
        </div>

        <script>
            document.getElementById('showChartButton').addEventListener('click', function() {
            // Gửi yêu cầu AJAX để lấy dữ liệu cho biểu đồ
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'chart_data.php', true);
            xhr.setRequestHeader('Content-type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.error) {
                        alert(response.error);
                    } else {
                        // Gọi hàm để vẽ biểu đồ với dữ liệu nhận được từ phản hồi
                        drawChart(response.labels, response.data);
                    }
                }
            };
            xhr.send(); // Gửi yêu cầu GET, không cần gửi bất kỳ dữ liệu nào
        });

        function drawChart(labels, data) {
            var ctx = document.createElement('canvas');
            document.getElementById('chartContainer').innerHTML = '';
            document.getElementById('chartContainer').appendChild(ctx);

            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Dữ liệu biểu đồ',
                        data: data,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
                </script>
        <?php
    } else {
        echo 'helo';
    }
?>

</body>
</html>
