<body>
    <div class="bg--outside">
        <form action="/payment_page" method="post">
        <?php
            $seatIDArray = array();      

            //get $_SESSION
            $film_ID = $_SESSION['filmID']; 
            $cluster_ID = $_SESSION['cluster_ID']; 
            $acc_ID = $_SESSION['accID']; 

            $film_Name = $_SESSION['film_Name'];
            $date = $_SESSION['Date'];
            $film_type = $_SESSION['film_type']; 
            $sht_Time = $_SESSION['sht_Time'];
            $area_Name = $_SESSION['area_Name'];
            $cluster_Name = $_SESSION['cluster_Name'];
            $room_ID = $_SESSION['room_ID'];     
            $room_Name = $_SESSION['room_Name'];

            $sht_ID = $_SESSION['sht_ID']; 
            
            foreach(getSeatByShtID($sht_ID) as $row){
                $seat_ID = $row['seat_ID'];
                $seat_Post_Name = 'booking-seat-tr__'.$seat_ID;
                if(!empty($_POST[$seat_Post_Name])){
            ?>
                <input type="hidden" name="booking-seat-tr__<?= $seat_ID ?>" value="<?= $seat_ID ?>">                
            <?php
                    $seatIDIsChoosing = $_POST[$seat_Post_Name];
                    array_push($seatIDArray, $seatIDIsChoosing);
                }

            }

            $seat_Number_array = array();
            $seat_Type_array = array();
            $seat_Price_array = array();
            $film_type_price = getFilmTypePrice($film_type);
            foreach($seatIDArray as $seatIDItems){
                foreach(getSeatBySeatIDJoinSeatType($seatIDItems) as $row){
                    $seatNumber = $row['seat_Number'];
                    $seatType = $row['seat_type'];
                    $seatPrice = $row['Price'];

                    array_push($seat_Number_array, $seatNumber);
                    array_push($seat_Type_array, $seatType);
                    array_push($seat_Price_array, $seatPrice + $film_type_price);

                }
            }
            $sumTicketPrice = array_sum($seat_Price_array);
            $sumVoucherPrice = 0;

    ?>
            <div class="container package__container">
                <div class="row package__content">
                    <!-- title -->
                    <h1 class="package__title">Chọn gói</h1>

                    <div class="package__list">

                        <?php
                            foreach(getAllCombo() as $row){
                                $combo_ID = $row['combo_ID'];
                                $combo_Name = $row['combo_Name'];
                                $combo_Describe = $row['combo_Description'];
                                $combo_Price = $row['Combo_Price'];
                                $combo_photo = $row['combo_Photo'];
                        ?>
                            <div title="<?= $combo_Describe ?>" class="package__items col-l-2-4 col-md-2-4 col-sm-6">
                                <img class="package__items--img" src="/assets/img/<?= $combo_photo ?>" alt="" srcset="">
                                <p class="package__items--about"><?= $combo_Name ?></p>
                                <p class="package__items--describe"><?= $combo_Describe ?></p>
                                <div class="package__items--price-list">
                                    <p class="package__items--price-header"><?= $combo_ID ?></p>
                                    <p class="package__items--price"><?= number_format($combo_Price) ?>$</p>
                                </div>
                            </div>

                        <?php
                            }
                        ?>
                    </div>
                    <!-- ticket info -->
                    <table cellspacing="0" class="package__table">
                        <tbody class="package__tbody">
                            <tr class="package__tr">
                                <th class="package__th"> <p class="package__th--para">Phim</p> </th>
                                <th class="package__th"> <p class="package__th--para">Thể loại phim</p> </th>
                                <th class="package__th"> <p class="package__th--para">Thời gian</p> </th>
                                <th class="package__th"> <p class="package__th--para">Ngày đặt</p> </th>
                                <th class="package__th"> <p class="package__th--para">Khu vực</p> </th>
                                <th class="package__th"> <p class="package__th--para">Danh mục</p> </th>
                                <th class="package__th"> <p class="package__th--para">Phòng</p> </th>
                                <th class="package__th"> <p class="package__th--para">Vị trí ngồi</p> </th>
                                <th class="package__th"> <p class="package__th--para">Thể loại ghế</p> </th>
                                <th class="package__th"> <p class="package__th--para">Giá tiền</p> </th>
                                <th class="package__th"> <p class="package__th--para">Gói</p> </th>
                            </tr>

                            <?php
                            $i = 0;
                            foreach($seatIDArray as $seat){
                            ?>
                            <tr class="package__tr">
                                <td class="package__td"><p class="package__td--para"><?= $film_Name ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $date ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $film_type ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $sht_Time ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $area_Name ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $cluster_Name ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $room_Name ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $seat_Number_array[$i] ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= $seat_Type_array[$i] ?></p></td>
                                <td class="package__td"><p class="package__td--para"><?= number_format($seat_Price_array[$i]) ?></p></td>
                                <td class="package__td">
                                    <select name="package__select--<?= $seat ?>" id="package__select--<?= $seat ?>" class="package__select">
                                        <option value="none" class="package__option">none</option>
                                        <?php
                                            foreach(getAllCombo() as $row){
                                                $combo_ID = $row['combo_ID'];
                                                $combo_Name = $row['combo_Name'];
                                                $combo_Describe = $row['combo_Description'];
                                                $combo_Price = $row['Combo_Price'];
                                                $combo_photo = $row['combo_Photo'];
                                        ?>

                                            <option value="<?= $combo_ID ?>" class="package__option"><?= $combo_ID ?></option>
                                        <?php
                                            }
                                        ?>
                                        
                                    </select>
                                </td>
                            </tr>
                            <?php
                            $i++;
                            }
                            ?>

                        </tbody>
                    </table>

                    <button class="package__btn" type="submit">Tiếp theo</button>
                </div>
            </div>

            <?php
            
            ?>
        </form>
    </div>
</body>