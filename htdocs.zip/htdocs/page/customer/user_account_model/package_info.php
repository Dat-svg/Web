<?php
    if(isset($_GET['package'])){
        $comboID = $_GET['package'];
        $_SESSION['pakage_id'] = $comboID;

        header('location: '. deleteURLPackageIDInPackage());
    }else{
        $comboID = $_SESSION['pakage_id'];
    }
    $dataCombo = getComboByComboID($comboID);
    $combo_Name = $dataCombo['combo_Name'];
    $combo_Description = $dataCombo['combo_Description'];
    $combo_Price = $dataCombo['Combo_Price'];
    $combo_photo = $dataCombo['combo_Photo'];
?>
<body>
    <h1 class="package__title--header voucher__title">Về thông tin gói</h1>

    <div class="voucher__content">
        <img class="package__content--img voucher__content--img col-l-5 col-md-5 col-sm-5" src="/assets/img/<?= $combo_photo ?>" alt="" srcset="">

        <p class="package__content--describe col-l-12 col-md-12 col-sm-12">Tên: <?= $combo_Name ?></p>
        <p class="package__content--describe col-l-12 col-md-12 col-sm-12">Mô tả: <?= $combo_Description ?></p>
        <p class="package__content--describe col-l-12 col-md-12 col-sm-12">Giá tiền: <?= number_format($combo_Price)?>$</p>

    </div>
</body>
<?php
    //header('location: index.php?page=error_1');
?>