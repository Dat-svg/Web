<?php
    $dataCus = getCusByPhone($_SESSION['login_phone']);
?>
<body>
    <form action="" id="myticket__form" method="post">

    <?php

    if($_GET['user'] == 'myticket'){
        if(isset($_GET['booking'])){
            
            $seatIDArray = array();

            $acc_ID = $_SESSION['accID'];
            $film_ID = $_SESSION['filmID'];
            $cluster_ID = $_SESSION['cluster_ID'];

            $film_Name = $_SESSION['film_Name'];
            $date = $_SESSION['Date'];
            $film_type = $_SESSION['film_type'];
            $sht_Time = $_SESSION['sht_Time'];
            $area_Name = $_SESSION['area_Name'];
            $cluster_Name = $_SESSION['cluster_Name'];
            $room_ID = $_SESSION['room_ID'];    
            $room_Name = $_SESSION['room_Name'];

            $sht_ID = $_SESSION['sht_ID'];

            $ticket_price = $_SESSION['ticket_price'];
            $voucher_ID = $_SESSION['voucher'];

            foreach(getSeatByShtID($sht_ID) as $row){
                $seat_ID = $row['seat_ID'];
                $seat_Post_Name = 'booking-seat-pay__'.$seat_ID;

                if(!empty($_SESSION[$seat_Post_Name])){
                    $seatIDIsChoosing = $_SESSION[$seat_Post_Name];
                    array_push($seatIDArray, $seatIDIsChoosing);
                    unset($_SESSION[$seat_Post_Name]);
                }
                
            }
            $combo_array = array();

            $seat_Number_array = array();
            $seat_Type_array = array();
            $seat_Price_array = array();
            $film_type_price = getFilmTypePrice($film_type);

            foreach($seatIDArray as $seatIDItems){
                $package_select_name = 'package__select--'.$seatIDItems;
                    $package_Items = $_SESSION[$package_select_name];
                    array_push($combo_array, $package_Items);
                    unset($_SESSION[$package_select_name]);

                foreach(getSeatBySeatIDJoinSeatType($seatIDItems) as $row){
                    $seatNumber = $row['seat_Number'];
                    $seatType = $row['seat_type'];
                    $seatPrice = $row['Price'];

                    array_push($seat_Number_array, $seatNumber);
                    array_push($seat_Type_array, $seatType);
                    array_push($seat_Price_array, $seatPrice + $film_type_price);

                }
            }
            
            // calculate combo price
            $combo_Price_array = array();
            foreach($combo_array as $combo_ID_Items){
                if($combo_ID_Items == 'none'){
                    array_push($combo_Price_array, 0);
                } else{
                    foreach(getAllCombo() as $row){
                        $combo_ID = $row['combo_ID'];
                        $combo_Price = $row['Combo_Price'];
                        if($combo_ID_Items == $combo_ID){
                            array_push($combo_Price_array, $combo_Price);
                        }
                    }
                }
            }

            $voucherPrice = 0;
            if(isset($_SESSION['voucher'])){

                if(checkVoucher($voucher_ID)){
                    $dataVoucher = getVoucherByVoucherID($voucher_ID);
                    $voucherPrice = $dataVoucher['voucher_Discount'];
                }else{
                    $voucher_ID = null;
                }
                
            }else{
                $voucher_ID = null;
            }

            $i = 0;
            foreach($seatIDArray as $seat_ID){
                $totalPrice = floatval($seat_Price_array[$i] - ($voucherPrice * $seat_Price_array[$i] / 100) + $combo_Price_array[$i]);
                insertTicket($acc_ID, $cluster_ID, $film_ID, $film_type, $sht_ID, $seat_ID, $room_ID, $voucher_ID, $totalPrice, $combo_array[$i]);
                updateShowTimeSeat($seat_ID, $sht_ID); 

                $i++;
            }
            header('location: '.deleteBookingDone());
    
        }
        ?>
            <h1 class="myticket__title">Vé của tôi</h1>
            <input style="text-align: center;display: flex; justify-content: center; margin:auto;" placeholder="Tìm kiếm vé trong tất cả" type="text" name="" id="search-input" class="manage-film__input">

            <table id="table" cellspacing="0" class="myticket__table">
                <tbody class="myticket__tbody">
                    <tr class=" myticket-tr--th">
                        <th class="myticket-th"><p class="myticket-th__para">Phim</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Ngày đặt vé</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Ngày chiếu</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Thể loại phim</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Thời gian</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Khu vực</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Danh mục</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Phòng</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Vị trí ngồi</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Thể loại ghế</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Mã khuyến mãi</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Gói Combo</p></th>
                        <th class="myticket-th"><p class="myticket-th__para">Giá tiền</p></th>
                    </tr>

                    <?php
                    $acc_ID = $dataCus['cus_ID'];
                        $i = 0;
                        foreach(getMyTicketTable($acc_ID) as $ticketInfo){
                            // Extract ticket information
                            $ticket_ID = $ticketInfo['ticket_ID'];
                            $film_Name = $ticketInfo['film_Name'];
                            $date = $ticketInfo['sht_Date'];
                            $date = dayReverse($date);
                            $film_type = $ticketInfo['type_Name'];
                            $sht_Time = $ticketInfo['sht_Time'];
                            $area_Name = $ticketInfo['area_Name'];
                            $cluster_Name = $ticketInfo['cluster_Name'];
                            $room_Name = $ticketInfo['room_Name'];
                            $seat_Number = $ticketInfo['seat_Number'];
                            $seat_Type = $ticketInfo['seat_type'];
                            $voucher_ID = $ticketInfo['voucher_ID'];
                            $booking_date = $ticketInfo['ticket_Date'];
                            $booking_date = dayReverse($booking_date);
                            if($voucher_ID == ''){
                                $voucher_ID = 'x';
                            }
                            $seat_Price = $ticketInfo['ticket_Price'];
                    ?>
                        <tr class="myticket-tr">
                            <td class="myticket-td"><p class="myticket-td__para"><?= $film_Name ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $booking_date ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $date ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $film_type ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $sht_Time ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $area_Name ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $cluster_Name ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $room_Name ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $seat_Number ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $seat_Type ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= $voucher_ID ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= getComboNameByTicketID($ticket_ID) ?></p></td>
                            <td class="myticket-td"><p class="myticket-td__para"><?= number_format($seat_Price) ?></p></td>
                            
                        </tr>
                    <?php
                        $i++;
                        }
                    ?>
                </tbody>
            </table>  
        <?php
    }else{
        header('location: index.php?page=error_1');
    }

    ?>
    </form>
</body>

<script>
    searchFilm()
</script>
