<?php
    require_once('../connectInCus.php');

    if(isset($_POST['voucherID']) && isset($_POST['priceTicket'])){
        $voucherPrice = 0;
        $voucher_ID = $_POST['voucherID'];

        // Kiểm tra xem voucher có tồn tại và hợp lệ không
        if(checkVoucher($voucher_ID)){
            $dataVoucher = getVoucherByVoucherID($voucher_ID);
            $voucherPrice = (float) $dataVoucher['voucher_Discount']; // Chuyển đổi giá trị voucher thành số thực
        }

        $ticketPrice = (float) $_POST['priceTicket']; // Chuyển đổi giá trị giá vé thành số thực

        // Kiểm tra xem giá vé và giá trị voucher có hợp lệ không
        if(is_numeric($ticketPrice) && is_numeric($voucherPrice)){
            $sum = $ticketPrice - ($voucherPrice * $ticketPrice) / 100;
            echo number_format($sum);
        } else {
            echo "Giá vé và giá khuyến mãi không tồn tạitại.";
        }
    } else {
        echo "Hết lượt sử dụng mã khuyến mãi hoặc hết vé.";
    }
?>