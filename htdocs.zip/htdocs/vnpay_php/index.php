<?php
    ob_start();
    session_start();
    include('../connect.php');

    $accID = $_SESSION['accID'];

    $ticketPrice = $_SESSION['ticket_price'];
    $voucher_ID = $_SESSION['voucher'];
    if($voucher_ID != null){
        $dataVoucher = getVoucherByVoucherID($voucher_ID);
        $voucherPrice = $dataVoucher['voucher_Discount'];
    }else{
        $voucherPrice = 0;
    }

    $sum = $ticketPrice - (floatval($voucherPrice) * $ticketPrice) / 100;
    
    $VND_money = $sum * 24000;


    $dataAcc = getCusByCusID($accID);

    $cus_Name = $dataAcc['cus_Name'];
    $cus_Email = $dataAcc['cus_Email'];
    $cus_Address = $dataAcc['cus_Address'];
    $cus_Phone = $dataAcc['cus_Phone_number'];
    $cus_DOB = $dataAcc['cus_DOB'];
    $cus_Sex = $dataAcc['cus_Sex'];

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>Tạo một hóa đơn mới</title>
        <link href="/vnpay_php/assets/bootstrap.min.css" rel="stylesheet"/>
        <link href="/vnpay_php/assets/jumbotron-narrow.css" rel="stylesheet">  
        <script src="/vnpay_php/assets/jquery-1.11.3.min.js"></script>
    </head>

    <body>
        <?php require_once("./config.php"); ?>             
        <div class="container">
            <div class="header clearfix">
                <h3 class="text-muted">THỬ NGHIỆM VNPAY</h3>
            </div>
            <h3>Tạo mới đơn hàng (Create a new order)</h3>
            <div class="table-responsive">
                <form action="/vnpay_php/vnpay_create_payment.php" id="create_form" method="post">       

                    <div class="form-group">
                        <label for="language">Loại hàng hóa (Commodities) </label>
                        <select name="order_type" id="order_type" class="form-control">
                            <option value="topup">Nạp tiền điện thoại (Recharge your phone)</option>
                            <option value="billpayment">Thanh toán hóa đơn (Pay the bill)</option>
                            <option value="fashion">Thời trang (Fashion)</option>
                            <option value="other">Khác - Xem thêm tại VNPAY (Other - See more at VNPAY)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="order_id">Mã hóa đơn (Order Code)</label>
                        <input class="form-control" id="order_id" name="order_id" type="text" value="<?php echo date("YmdHis") ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="amount">Số tiền (Money)</label>
                        <input class="form-control" id="amount"
                               name="amount" type="number" value="<?= $VND_money ?>"/>
                    </div>
                    <div class="form-group">
                        <label for="order_desc">Nội dung thanh toán (Content billing)</label>
                        <textarea class="form-control" cols="20" id="order_desc" name="order_desc" rows="2">Nội dung cần thanh toán</textarea>
                    </div>
                    <div class="form-group">
                        <label for="bank_code">Ngân hàng (Bank)</label>
                        <select name="bank_code" id="bank_code" class="form-control">
                            <option value="">Không chọn (No choice)</option>
                            <option value="NCB"> Ngân hàng NCB</option>
                            <option value="AGRIBANK"> Ngân hàng Agribank</option>
                            <option value="SCB"> Ngân hàng SCB</option>
                            <option value="SACOMBANK">Ngân hàng SacomBank</option>
                            <option value="EXIMBANK"> Ngân hàng EximBank</option>
                            <option value="MSBANK"> Ngân hàng MSBANK</option>
                            <option value="NAMABANK"> Ngân hàng NamABank</option>
                            <option value="VNMART"> Vi dien tu VnMart</option>
                            <option value="VIETINBANK">Ngân hàng Vietinbank</option>
                            <option value="VIETCOMBANK"> Ngân hàng VCB</option>
                            <option value="HDBANK">Ngân hàng HDBank</option>
                            <option value="DONGABANK"> Ngân hàng Dong A</option>
                            <option value="TPBANK"> Ngân hàng TPBank</option>
                            <option value="OJB"> Ngân hàng OceanBank</option>
                            <option value="BIDV"> Ngân hàng BIDV</option>
                            <option value="TECHCOMBANK"> Ngân hàng Techcombank</option>
                            <option value="VPBANK"> Ngân hàng VPBank</option>
                            <option value="MBBANK"> Ngân hàng MBBank</option>
                            <option value="ACB"> Ngân hàng ACB</option>
                            <option value="OCB"> Ngân hàng OCB</option>
                            <option value="IVB"> Ngân hàng IVB</option>
                            <option value="VISA"> Thanh toán qua VISA/MASTER</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="language">Ngôn ngữ (Language)</label>
                        <select name="language" id="language" class="form-control">
                            <option value="vn">Tiếng Việt (Vietnamese)</option>
                            <option value="en">English</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label >Thời hạn thanh toán (Payment term)</label>
                        <input class="form-control" id="txtexpire"
                               name="txtexpire" type="text" value="<?php echo $expire; ?>"/>
                    </div>
                    <div class="form-group">
                        <h3>Thông tin hóa đơn (Billing)</h3>
                    </div>
                    <div class="form-group">
                        <label >Họ tên (*) (Full name)</label>
                        <input class="form-control" id="txt_billing_fullname"
                               name="txt_billing_fullname" type="text" value="NGUYEN VAN TI TEO"/>             
                    </div>
                    <div class="form-group">
                        <label >Email (*)</label>
                        <input class="form-control" id="txt_billing_email"
                               name="txt_billing_email" type="text" value="titeo@vnpay.vn"/>   
                    </div>
                    <div class="form-group">
                        <label >Số điện thoại (*) (Phone number)</label>
                        <input class="form-control" id="txt_billing_mobile"
                               name="txt_billing_mobile" type="text" value="0985672342"/>   
                    </div>
                    <div class="form-group">
                        <label >Địa chỉ (*) (Address)</label>
                        <input class="form-control" id="txt_billing_addr1"
                               name="txt_billing_addr1" type="text" value="22 Đống Đa, Hà Nội"/>   
                    </div>
                    <div class="form-group">
                        <label >Mã bưu điện (*) (ZIP code) </label>
                        <input class="form-control" id="txt_postalcode"
                               name="txt_postalcode" type="text" value="224467"/> 
                    </div>
                    <div class="form-group">
                        <label >Tỉnh/TP (*) (Province/City) </label>
                        <input class="form-control" id="txt_bill_city"
                               name="txt_bill_city" type="text" value="Hà Nội"/> 
                    </div>
                    <div class="form-group">
                        <label>Bang (Áp dụng cho US,CA) (State (Applies to US, CA))</label>
                        <input class="form-control" id="txt_bill_state"
                               name="txt_bill_state" type="text" value=""/>
                    </div>
                    <div class="form-group">
                        <label >Quốc gia (*) (Nation)</label>
                        <input class="form-control" id="txt_bill_country"
                               name="txt_bill_country" type="text" value="VN"/>
                    </div>
                    <div class="form-group">
                        <h3>Thông tin giao hàng (Shipping)</h3>
                    </div>
                    <div class="form-group">
                        <label >Họ tên (*) (Full name)</label>
                        <input class="form-control" id="txt_ship_fullname"
                               name="txt_ship_fullname" type="text" value="Nguyễn Thế Quốc Bảo"/>
                    </div>
                    <div class="form-group">
                        <label >Email (*)</label>
                        <input class="form-control" id="txt_ship_email"
                               name="txt_ship_email" type="text" value="quocbaont@vnpay.vn"/>
                    </div>
                    <div class="form-group">
                        <label >Số điện thoại (*) (Phone number) </label>
                        <input class="form-control" id="txt_ship_mobile"
                               name="txt_ship_mobile" type="text" value="0678923141"/>
                    </div>
                    <div class="form-group">
                        <label >Địa chỉ (*) (Address)</label>
                        <input class="form-control" id="txt_ship_addr1"
                               name="txt_ship_addr1" type="text" value="Hà Nội, Việt Nam"/>
                    </div>
                    <div class="form-group">
                        <label >Mã bưu điện (*) (ZIP Code) </label>
                        <input class="form-control" id="txt_ship_postalcode"
                               name="txt_ship_postalcode" type="text" value="224467"/>
                    </div>
                    <div class="form-group">
                        <label >Tỉnh/TP (*) (Province/City)</label>
                        <input class="form-control" id="txt_ship_city"
                               name="txt_ship_city" type="text" value="Hà Nội"/>
                    </div>
                    <div class="form-group">
                        <label>Bang (Áp dụng cho US,CA) (State (Applies to US, CA))</label>
                        <input class="form-control" id="txt_ship_state"
                               name="txt_ship_state" type="text" value=""/>
                    </div>
                    <div class="form-group">
                        <label >Quốc gia (*) (Nation)</label>
                        <input class="form-control" id="txt_ship_country"
                               name="txt_ship_country" type="text" value="VN"/>
                    </div>
                    <div class="form-group">
                        <h3>Thông tin gửi Hóa đơn điện tử (Invoice)</h3>
                    </div>
                    <div class="form-group">
                        <label >Tên khách hàng (Customer Name)</label>
                        <input class="form-control" id="txt_inv_customer"
                               name="txt_inv_customer" type="text" value="<?= $cus_Name ?>"/>
                    </div>
                    <div class="form-group">
                        <label >Công ty (Company)</label>
                        <input class="form-control" id="txt_inv_company"
                               name="txt_inv_company" type="text" value=""/>
                    </div>
                    <div class="form-group">
                        <label >Địa chỉ (Address)</label>
                        <input class="form-control" id="txt_inv_addr1"
                               name="txt_inv_addr1" type="text" value="<?= $cus_Address ?>"/>
                    </div>
                    <div class="form-group">
                        <label>Mã số thuế (Tax code)</label>
                        <input class="form-control" id="txt_inv_taxcode"
                               name="txt_inv_taxcode" type="text" value=""/>
                    </div>
                    <div class="form-group">
                        <label >Loại hóa đơn (Bills)</label>
                        <select name="cbo_inv_type" id="cbo_inv_type" class="form-control">
                            <option value="I">Cá Nhân (Individual)</option>
                            <option value="O">Công ty/Tổ chức (Company/Organization)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label >Email</label>
                        <input class="form-control" id="txt_inv_email"
                               name="txt_inv_email" type="text" value="<?= $cus_Email ?>"/>
                    </div>
                    <div class="form-group">
                        <label >Điện thoại (Phone number)</label>
                        <input class="form-control" id="txt_inv_mobile"
                               name="txt_inv_mobile" type="text" value="<?= $cus_Phone ?>"/>
                    </div>
                    <button type="submit" class="btn btn-primary" id="btnPopup">Thanh toán Post (Post Payment)</button>
                    <button type="submit" name="redirect" id="redirect" class="btn btn-default">Thanh toán Redirect (Redirect Payment)</button>

                </form>
            </div>
            <p>
                &nbsp;
            </p>
            <footer class="footer">
                <p>&copy; VNPAY <?php echo date('Y')?></p>
            </footer>
        </div>  

        <script>
            $(document).ready(function(){
                $('#btnPopup').click(function(e){
                    e.preventDefault(); // Ngăn chặn hành động mặc định của nút
                    alert('Tính năng đang bảo trì!');
                });
            });
        </script>


    </body>
</html>
