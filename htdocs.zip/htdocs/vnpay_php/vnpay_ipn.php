﻿<?php
    require_once("./config.php");
    $inputData = array();
    $returnData = array();
    foreach ($_GET as $key => $value) {
                if (substr($key, 0, 4) == "vnp_") {
                    $inputData[$key] = $value;
                }
            }

    $vnp_SecureHash = $inputData['vnp_SecureHash'];
    unset($inputData['vnp_SecureHash']);
    ksort($inputData);
    $i = 0;
    $hashData = "";
    foreach ($inputData as $key => $value) {
        if ($i == 1) {
            $hashData = $hashData . '&' . urlencode($key) . "=" . urlencode($value);
        } else {
            $hashData = $hashData . urlencode($key) . "=" . urlencode($value);
            $i = 1;
        }
    }

    $secureHash = hash_hmac('sha512', $hashData, $vnp_HashSecret);
    $vnpTranId = $inputData['vnp_TransactionNo'];
    $vnp_BankCode = $inputData['vnp_BankCode'];
    $vnp_Amount = $inputData['vnp_Amount']/100;

    $Status = 0;
    $orderId = $inputData['vnp_TxnRef'];

    try {

        if ($secureHash == $vnp_SecureHash) {  

            $order = NULL;
            if ($order != NULL) {
                if($order["Amount"] == $vnp_Amount) //Kiểm tra số tiền thanh toán của giao dịch: giả sử số tiền kiểm tra là đúng. //$order["Amount"] == $vnp_Amount
                {
                    if ($order["Status"] != NULL && $order["Status"] == 0) {
                        if ($params['vnp_ResponseCode'] == '00' || $params['vnp_TransactionStatus'] == '00') {
                            $Status = 1; // Trạng thái thanh toán thành công
                        } else {
                            $Status = 2; // Trạng thái thanh toán thất bại / lỗi
                        }            
                        $returnData['RspCode'] = '00';
                        $returnData['Message'] = 'Thành công!';
                    } else {
                        $returnData['RspCode'] = '02';
                        $returnData['Message'] = 'Giao dịch đã thành công!';
                    }
                }
                else {
                    $returnData['RspCode'] = '04';
                    $returnData['Message'] = 'Số lượng không hợp lệ!';
                }
            } else {
                $returnData['RspCode'] = '01';
                $returnData['Message'] = 'Không tìm thấy đặt hàng!';
            }
        } else {
            $returnData['RspCode'] = '97';
            $returnData['Message'] = 'Chữ ký không hợp lệ!';
        }
    } catch (Exception $e) {
        $returnData['RspCode'] = '99';
        $returnData['Message'] = 'Unknow error!';
    }
    //Trả lại VNPAY theo định dạng JSON
    echo json_encode($returnData);
?>